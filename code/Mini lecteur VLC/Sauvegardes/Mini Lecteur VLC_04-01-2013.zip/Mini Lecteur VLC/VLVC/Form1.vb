﻿Imports AXVLC




Public Class Form1

    Public WithEvents objVlc As VLCPlugin
    Private Voptions() As Object

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        If objVlc Is Nothing Then
            objVlc = New AXVLC.VLCPlugin
        End If



        objVlc.addTarget("http://tvieil.dnsalias.com/AlbumPhotos/14/Muse_-_Sing_For_Absolution.flv", Voptions, 1, -666)
        objVlc.Volume = 100
        objVlc.Play()
    End Sub

    Private Sub Play_Click(sender As System.Object, e As System.EventArgs) Handles Play.Click
        objVlc.Volume = 100
        objVlc.play()
    End Sub

    Private Sub Pause_Click(sender As System.Object, e As System.EventArgs) Handles Pause.Click

        objVlc.pause()

    End Sub

    Private Sub ButtonStop_Click(sender As System.Object, e As System.EventArgs) Handles ButtonStop.Click

        objVlc.stop()

    End Sub

    Private Sub ButtonMute_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMute.Click

        If (objVlc.Volume = 0) Then
            objVlc.Volume = 100
        Else
            objVlc.Volume = 0
        End If

    End Sub

    Private Sub ButtonFullscreen_Click(sender As System.Object, e As System.EventArgs) Handles ButtonFullscreen.Click

        objVlc.fullscreen()

    End Sub
End Class
