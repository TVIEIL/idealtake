﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Play = New System.Windows.Forms.Button()
        Me.Pause = New System.Windows.Forms.Button()
        Me.ButtonStop = New System.Windows.Forms.Button()
        Me.ButtonMute = New System.Windows.Forms.Button()
        Me.ButtonFullscreen = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Play
        '
        Me.Play.Location = New System.Drawing.Point(13, 83)
        Me.Play.Name = "Play"
        Me.Play.Size = New System.Drawing.Size(75, 23)
        Me.Play.TabIndex = 0
        Me.Play.Text = "Play"
        Me.Play.UseVisualStyleBackColor = True
        '
        'Pause
        '
        Me.Pause.Location = New System.Drawing.Point(13, 113)
        Me.Pause.Name = "Pause"
        Me.Pause.Size = New System.Drawing.Size(75, 23)
        Me.Pause.TabIndex = 1
        Me.Pause.Text = "Pause"
        Me.Pause.UseVisualStyleBackColor = True
        '
        'ButtonStop
        '
        Me.ButtonStop.Location = New System.Drawing.Point(13, 143)
        Me.ButtonStop.Name = "ButtonStop"
        Me.ButtonStop.Size = New System.Drawing.Size(75, 23)
        Me.ButtonStop.TabIndex = 2
        Me.ButtonStop.Text = "Stop"
        Me.ButtonStop.UseVisualStyleBackColor = True
        '
        'ButtonMute
        '
        Me.ButtonMute.Location = New System.Drawing.Point(13, 173)
        Me.ButtonMute.Name = "ButtonMute"
        Me.ButtonMute.Size = New System.Drawing.Size(75, 23)
        Me.ButtonMute.TabIndex = 3
        Me.ButtonMute.Text = "Mute"
        Me.ButtonMute.UseVisualStyleBackColor = True
        '
        'ButtonFullscreen
        '
        Me.ButtonFullscreen.Location = New System.Drawing.Point(13, 203)
        Me.ButtonFullscreen.Name = "ButtonFullscreen"
        Me.ButtonFullscreen.Size = New System.Drawing.Size(75, 23)
        Me.ButtonFullscreen.TabIndex = 4
        Me.ButtonFullscreen.Text = "Fullscreen"
        Me.ButtonFullscreen.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.ButtonFullscreen)
        Me.Controls.Add(Me.ButtonMute)
        Me.Controls.Add(Me.ButtonStop)
        Me.Controls.Add(Me.Pause)
        Me.Controls.Add(Me.Play)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Play As System.Windows.Forms.Button
    Friend WithEvents Pause As System.Windows.Forms.Button
    Friend WithEvents ButtonStop As System.Windows.Forms.Button
    Friend WithEvents ButtonMute As System.Windows.Forms.Button
    Friend WithEvents ButtonFullscreen As System.Windows.Forms.Button

End Class
